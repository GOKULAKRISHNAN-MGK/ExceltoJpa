package com.mgk.ExceltoJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceltoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
