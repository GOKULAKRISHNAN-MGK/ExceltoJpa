package com.mgk.ExceltoJpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mgk.ExceltoJpa.service.FileReadServiceImpl;



@RestController
public class FileReadController {
	
	@Autowired
	private FileReadServiceImpl fileReadService;
	
	@RequestMapping(value="/",method=RequestMethod.POST)
	public void uploadFile(MultipartFile file)
	{
		fileReadService.saveDataFromFile(file);
	}

}
