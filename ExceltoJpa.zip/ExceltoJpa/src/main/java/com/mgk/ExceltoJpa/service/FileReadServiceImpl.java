package com.mgk.ExceltoJpa.service;

import java.util.Iterator;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mgk.ExceltoJpa.model.User;
import com.mgk.ExceltoJpa.repository.FileReadRepo;

@Service
public class FileReadServiceImpl {
	
	@Autowired
	private FileReadRepo fileReadRepo;

	
	public void saveDataFromFile(MultipartFile file) {
		Workbook workbook=getWorkBook(file);
		Sheet sheet=workbook.getSheetAt(0);
		Iterator<Row> rows=sheet.iterator();
		rows.next();
		while(rows.hasNext())
		{
			Row row = rows.next();
			User user=new User();
			user.setName(row.getCell(0).getStringCellValue());
			user.setEmail(row.getCell(1).getStringCellValue());
			fileReadRepo.save(user);
		}
	}

	private Workbook getWorkBook(MultipartFile file) {
		Workbook workbook=null;
		String extension=FilenameUtils.getExtension(file.getOriginalFilename());
		try {
			if(extension.equalsIgnoreCase("xlsx"))
			{
				workbook=new XSSFWorkbook(file.getInputStream());
			}
			else if(extension.equalsIgnoreCase("xls"))
			{
				workbook=new HSSFWorkbook(file.getInputStream());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return workbook;
	}

}
