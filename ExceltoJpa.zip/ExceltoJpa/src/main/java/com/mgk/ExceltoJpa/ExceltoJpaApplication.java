package com.mgk.ExceltoJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceltoJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceltoJpaApplication.class, args);
	}

}
