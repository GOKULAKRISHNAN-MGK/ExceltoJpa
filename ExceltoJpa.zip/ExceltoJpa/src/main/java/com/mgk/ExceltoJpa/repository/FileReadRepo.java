package com.mgk.ExceltoJpa.repository;

import org.springframework.data.repository.CrudRepository;

import com.mgk.ExceltoJpa.model.User;

public interface FileReadRepo extends CrudRepository<User, Long> {

}
